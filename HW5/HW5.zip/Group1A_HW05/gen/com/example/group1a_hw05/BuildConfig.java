/** Automatically generated file. DO NOT MODIFY */
package com.example.group1a_hw05;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}